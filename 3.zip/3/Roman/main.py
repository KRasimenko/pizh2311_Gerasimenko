from RomanCalculator import RomanCalculator



calculator = RomanCalculator()
calculator.run()