from Terminal import Terminal

def main():
    terminal = Terminal()
    terminal.run()

if __name__ == "__main__":
    main()

