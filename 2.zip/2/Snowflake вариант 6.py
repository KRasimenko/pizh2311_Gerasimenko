from Snowy import SnowFlake

s = SnowFlake()
s()
s('thaw', 1)
s()
s('freeze', 1)
s()
s('thicken')
s()

    

