# Программирование на языке высокого уровня (Python).
# Задание №4. Вариант 6
#
# Выполнил: Герасименко Константин Васильевич
# Группа: ПИЖ-б-о-23-1
# E-mail: kostiktell@mail.ru


from loanValidator import LoanInterface

if __name__ == "__main__":
    calculator = LoanInterface()
    calculator.run()
